
import { PortfolioView } from './components/portfolio/PortfolioView';
import config from './config.json';
// import { PortfolioConfig } from './types/config'; // Types issues with JSON import sometimes, casting is safer

function App() {
  return (
    <div className="bg-black min-h-screen text-white">
      <PortfolioView config={config as any} />
    </div>
  );
}

export default App;
